#include <stdio.h>
#include "tests/threads/tests.h"

void test_hello_world(void){
    printf("hello world!!! ciallo~~~~ \n");
}